<p align="center">
<img src='.github/img/ytp.gif'  >
</p>
<h1 align=center>YT PRO </h1>

<div align="center">

[![Gradle](https://github.com/prateek-chaubey/YTPro/actions/workflows/gradle.yml/badge.svg)](https://github.com/prateek-chaubey/YTPro/actions/workflows/gradle.yml)
<img alt="jsDelivr monthly hits badge" src="https://data.jsdelivr.com/v1/package/gh/prateek-chaubey/YTPro/badge">

[![https://telegram.me/th30neand0nly0ne](https://img.shields.io/badge/Telegram-Channel-orange.svg?style=flat-square)](https://telegram.me/th30neand0nly0ne)
[![https://telegram.me/th30neand0nly](https://img.shields.io/badge/Telegram-@th30neand0nly-blue.svg?style=flat-square)](https://telegram.me/th30neand0nly)

</div>

---


| | |
|:--:|:--:| 
|<img src='.github/img/ytpro3.png'  > | <img src='.github/img/ytpro2.png'  > |


## Download YT PRO

[![Download zip](https://custom-icon-badges.herokuapp.com/badge/-Download-ff0000?style=for-the-badge&logo=download&logoColor=white "Download Apk")](https://github.com/prateek-chaubey/YTPro/releases/download/v2.3/YTPRO.apk)

## Features
 * Video Downloader
 * Ads Blocker
 * Picture in Picture Mode
 * Shows Number of Dislikes
 * Background Audio Player
 * APK size under 30KB
 * Minimal
 * Almost 0 Dependencies

## ToDo
 * Improve PIP and Background Player


### ❤️Supporters❤️
[![Stargazers repo roster for @prateek-chaubey/YTPro](https://reporoster.com/stars/dark/prateek-chaubey/YTPro)](https://github.com/prateek-chaubey/YTPro/stargazers)
     
[![Forkers repo roster for @prateek-chaubey/YTPro](https://reporoster.com/forks/dark/prateek-chaubey/YTPro)](https://github.com/prateek-chaubey/YTPro/network/members)
